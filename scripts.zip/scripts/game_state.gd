extends Node
# Global oyun durumu (autoload). Tüm sistemler buradan okur/yazar.

signal changed
signal item_collected(text: String)

var max_hp := 5
var hp := 5
var pollution := 0.0          # 0-100
var recycle_stock := 0        # Boss savaşında kullanılacak itemler
var trash_stock := 0
var recycled_total := 0
var trash_total := 0
var dirty_total := 0          # Boss'ta kullanılan çöp bombası sayısı
var upgrades := {"double_jump": false, "speed": 0, "damage": 0, "shield": 0}


func _ready() -> void:
    _add_action("left", [KEY_A, KEY_LEFT])
    _add_action("right", [KEY_D, KEY_RIGHT])
    _add_action("up", [KEY_W, KEY_UP])
    _add_action("down", [KEY_S, KEY_DOWN])
    _add_action("jump", [KEY_SPACE, KEY_W, KEY_UP])
    _add_action("attack", [KEY_J, KEY_X, KEY_Z])


func _add_action(action_name: String, keys: Array) -> void:
    if not InputMap.has_action(action_name):
        InputMap.add_action(action_name)
    for k in keys:
        var e := InputEventKey.new()
        e.physical_keycode = k
        InputMap.action_add_event(action_name, e)


func reset() -> void:
    max_hp = 5
    hp = 5
    pollution = 0.0
    recycle_stock = 0
    trash_stock = 0
    recycled_total = 0
    trash_total = 0
    dirty_total = 0
    upgrades = {"double_jump": false, "speed": 0, "damage": 0, "shield": 0}
    changed.emit()


func add_pollution(amount: float) -> void:
    pollution = clampf(pollution + amount, 0.0, 100.0)
    changed.emit()


func apply_item(kind: String) -> void:
    var text := ""
    if kind == "recycle":
        recycled_total += 1
        recycle_stock += 1
        add_pollution(-8.0)
        var pool: Array = ["speed", "shield", "heal"]
        if not upgrades["double_jump"]:
            pool.append("double_jump")
            pool.append("double_jump")
        var pick: String = pool.pick_random()
        match pick:
            "double_jump":
                upgrades["double_jump"] = true
                text = "GERİ DÖNÜŞÜM: Çift zıplama!"
            "speed":
                upgrades["speed"] += 1
                text = "GERİ DÖNÜŞÜM: Hız artışı!"
            "shield":
                upgrades["shield"] += 1
                text = "GERİ DÖNÜŞÜM: Kalkan (1 hasarı emer)!"
            "heal":
                hp = mini(hp + 1, max_hp)
                text = "GERİ DÖNÜŞÜM: +1 can!"
    else:
        trash_total += 1
        trash_stock += 1
        upgrades["damage"] += 1
        add_pollution(12.0)
        text = "ÇÖP: Hasar +1 ama kirlilik arttı!"
    changed.emit()
    item_collected.emit(text)
